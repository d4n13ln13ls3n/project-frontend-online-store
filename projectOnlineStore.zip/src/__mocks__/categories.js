module.exports = [{
  id: 'MLB5672',
  name: 'Acessórios para Veículos',
}, {
  id: 'MLB271599',
  name: 'Agro',
}, {
  id: 'MLB1403',
  name: 'Alimentos e Bebidas',
}];
